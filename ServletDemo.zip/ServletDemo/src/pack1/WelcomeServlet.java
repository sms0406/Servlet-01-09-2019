package pack1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public WelcomeServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside doget");
		PrintWriter writer = response.getWriter();
		
		writer.println("<html><body><b>Welocme" + request.getParameter("userName")+ " ,"+request.getAttribute("var1")+"</b></body></html>");
		
		RequestDispatcher rd = request.getRequestDispatcher("/foot");
		rd.include(request, response);
		writer.println("end of page");
		
		ServletContext context = getServletContext();
		System.out.println("from Welcomeservlet do post "+context.getInitParameter("name"));
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("inside dopost");
		doGet(request, response);
	}

}
