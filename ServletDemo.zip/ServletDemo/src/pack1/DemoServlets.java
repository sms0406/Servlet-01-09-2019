package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/hello")
public class DemoServlets extends GenericServlet{

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Calendar c=Calendar.getInstance();
		System.out.println(c);
		PrintWriter pw=arg1.getWriter();
		pw.println(Calendar.getInstance().getTime());
	}
}
