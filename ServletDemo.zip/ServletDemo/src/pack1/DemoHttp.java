package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
@WebServlet("/hi")
public class DemoHttp extends HttpServlet{
	public void doGet(HttpServletRequest arg0,HttpServletResponse arg1) throws IOException
	{
//		Calendar c=Calendar.getInstance();
		
		String name=arg0.getParameter("userName");
		Integer age=Integer.parseInt(arg0.getParameter("age"));
		String qualifications[]=arg0.getParameterValues("qua");
		PrintWriter pw=arg1.getWriter();
		pw.println(name + "  "+age);
		for(String s: qualifications)
			pw.println(s+"  : ");
		String query=arg0.getQueryString();
		pw.println(query);
		String client=arg0.getRemoteAddr();
		arg0.getAttributeNames();
		arg0.getParameterNames();
		
	}
	public void doPost(HttpServletRequest arg0,HttpServletResponse arg1) throws IOException
	{
		String name=arg0.getParameter("userName");
		Integer age=Integer.parseInt(arg0.getParameter("age"));
		String qualifications[]=arg0.getParameterValues("qua");
		PrintWriter pw=arg1.getWriter();
		pw.println(name + "  "+age);
		for(String s: qualifications)
			pw.println(s+"  : ");
		String query=arg0.getQueryString();
		pw.println(query);
		arg0.getAttributeNames();
		arg0.getParameterNames();
/*//		Calendar c=Calendar.getInstance();
		String name=arg0.getParameter("userName");
		Integer age=Integer.parseInt(arg0.getParameter("age"));
		String qualifications[]=arg0.getParameterValues("qua");
		PrintWriter pw=arg1.getWriter();
		pw.println(name + "  "+age);
		for(String s: qualifications)
			pw.println(s+"  : ");
		
	
		if(name.equalsIgnoreCase("admin"))
		
		pw.println("login success!");
		else
			pw.print("failure");*/
	}

}
